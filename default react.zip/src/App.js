import { Routes, Route } from "react-router-dom";
import AuthProvider from "./Context/AuthPorvider/AuthProvider";
import PrivateRoute from "./Routes/PrivateRoute";
import Admin from "./Views/Admin/Layouts/Admin";
import AdminHome from "./Views/Admin/Pages/AdminHome";
import { AdminOrders, AdminProducts } from "./Views/Admin/Pages/AdminPages";
import NotFound from "./Views/Errors/NotFound";
import Login from "./Views/Frontend/auth/Login";
import Frontend from "./Views/Frontend/Layouts/Frontend";
import About from "./Views/Frontend/pages/About";
import Contact from "./Views/Frontend/pages/Contact";
import Home from "./Views/Frontend/pages/Home";

function App() {
    return (
        <div>
            <AuthProvider>
                <Routes>
                    {/* public routes */}
                    <Route path="/" element={<Frontend />}>
                        <Route index element={<Home />} />
                        <Route path="about" element={<About />} />
                        <Route path="contact" element={<Contact />} />
                        <Route path="login" element={<Login />} />
                        {/* Using path="*"" means "match anything", so this route
                            acts like a catch-all for URLs that we don't have explicit
                            routes for. */}
                        <Route path="*" element={<NotFound />} />
                    </Route>

                    {/* admin routes */}
                    <Route path="/dashboard" element={<Admin />}>
                        <Route
                            index
                            element={
                                <PrivateRoute>
                                    <AdminHome></AdminHome>
                                </PrivateRoute>
                            }>
                        </Route>
                        <Route
                            path="orders"
                            element={
                                <PrivateRoute>
                                    <AdminOrders></AdminOrders>
                                </PrivateRoute>
                            }>
                        </Route>
                        <Route
                            path="products"
                            element={
                                <PrivateRoute>
                                    <AdminProducts></AdminProducts>
                                </PrivateRoute>
                            }>
                        </Route>
                        <Route path="*" element={<NotFound />} />
                    </Route>
                </Routes>
            </AuthProvider>
        </div>
    );
}

export default App;
