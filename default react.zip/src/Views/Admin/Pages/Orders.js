import React from 'react'

function Orders() {
    return (
        <div>
            <h1>Orders</h1>
        </div>
    )
}

export default Orders
