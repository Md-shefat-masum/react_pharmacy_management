import React from 'react'

export default function AdminHome() {
    return (
        <div>
            <h1>dashboard</h1>
        </div>
    )
}
