import React from 'react'

function Products() {
    return (
        <div>
            <h1>products</h1>
        </div>
    )
}

export default Products
