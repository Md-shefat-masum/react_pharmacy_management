import React from "react";
import { UseAuth } from "../../../Hooks/UseAuth";

export default function Login() {
    console.log(UseAuth());
    let { login_with_google } = UseAuth();
    const handleLogin = () => {
        login_with_google();
    }
    return (
        <section>
            <div className="container">
                <div className="row">
                    <div className="card">
                        <div className="card-body">
                            <form action="">
                                <button type="button" onClick={() => handleLogin()}>login</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

